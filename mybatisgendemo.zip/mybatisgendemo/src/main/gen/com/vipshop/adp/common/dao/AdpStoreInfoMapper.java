package com.vipshop.adp.common.dao;

import com.vipshop.adp.common.entity.AdpStoreInfo;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AdpStoreInfoMapper {
    int deleteById(Long id);

    int insert(AdpStoreInfo record);

    int insertSelective(AdpStoreInfo record);

    AdpStoreInfo selectById(Long id);

    int updateSelective(AdpStoreInfo record);

    int update(AdpStoreInfo record);

    List<AdpStoreInfo> selectByFeature(AdpStoreInfo feature);

    List<AdpStoreInfo> selectByFieldList(@Param("field") String field, @Param("values") List<?> values);

    int deleteByFeature(AdpStoreInfo feature);

    List<AdpStoreInfo> selectByCriteria(QCriteria criteria);

    List<Map<String, Object>> selectRawByCriteria(SelectableCriteria criteria);
}