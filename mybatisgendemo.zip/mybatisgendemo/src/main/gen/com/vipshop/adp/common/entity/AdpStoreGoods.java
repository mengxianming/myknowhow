package com.vipshop.adp.common.entity;

import java.io.Serializable;
import java.util.Date;

public class AdpStoreGoods implements Serializable {
    private static final long serialVersionUID = 1L;

    /** 主键
     */
    private Long id;

    /** 用户ID
     */
    private Long userId;

    /** 店铺ID
     */
    private Long storeId;

    /** 特卖会商品ID, json格式
     */
    private String goodsIds;

    /** 特卖会档期id, json格式
     */
    private String brandIds;

    /** 方案码
     */
    private String schemeCode;

    /** 店铺广告位：（0:未知，1：店铺动态，2：热门活动，3：种草好物）
     */
    private Short storeAd;

    /** 分享消息
     */
    private String cpsBreif;

    /** 置顶状态 // 1：置顶， 0：未置顶
     */
    private Byte isTop;

    /** 有效状态 // 1：有效， 0：无效
     */
    private Byte isActive;

    /** 删除状态 // 1：已删除， 0：未删除
     */
    private Byte isDeleted;

    /** 创建人id
     */
    private Long createBy;

    /** 创建时间
     */
    private Date createTime;

    /** 更新人id
     */
    private Long updateBy;

    /** 更新时间
     */
    private Date updateTime;

    /**
     * 获取主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取用户ID
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * 设置用户ID
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * 获取店铺ID
     */
    public Long getStoreId() {
        return storeId;
    }

    /**
     * 设置店铺ID
     */
    public void setStoreId(Long storeId) {
        this.storeId = storeId;
    }

    /**
     * 获取特卖会商品ID, json格式
     */
    public String getGoodsIds() {
        return goodsIds;
    }

    /**
     * 设置特卖会商品ID, json格式
     */
    public void setGoodsIds(String goodsIds) {
        this.goodsIds = goodsIds == null ? null : goodsIds.trim();
    }

    /**
     * 获取特卖会档期id, json格式
     */
    public String getBrandIds() {
        return brandIds;
    }

    /**
     * 设置特卖会档期id, json格式
     */
    public void setBrandIds(String brandIds) {
        this.brandIds = brandIds == null ? null : brandIds.trim();
    }

    /**
     * 获取方案码
     */
    public String getSchemeCode() {
        return schemeCode;
    }

    /**
     * 设置方案码
     */
    public void setSchemeCode(String schemeCode) {
        this.schemeCode = schemeCode == null ? null : schemeCode.trim();
    }

    /**
     * 获取店铺广告位：（0:未知，1：店铺动态，2：热门活动，3：种草好物）
     */
    public Short getStoreAd() {
        return storeAd;
    }

    /**
     * 设置店铺广告位：（0:未知，1：店铺动态，2：热门活动，3：种草好物）
     */
    public void setStoreAd(Short storeAd) {
        this.storeAd = storeAd;
    }

    /**
     * 获取分享消息
     */
    public String getCpsBreif() {
        return cpsBreif;
    }

    /**
     * 设置分享消息
     */
    public void setCpsBreif(String cpsBreif) {
        this.cpsBreif = cpsBreif == null ? null : cpsBreif.trim();
    }

    /**
     * 获取置顶状态 // 1：置顶， 0：未置顶
     */
    public Byte getIsTop() {
        return isTop;
    }

    /**
     * 设置置顶状态 // 1：置顶， 0：未置顶
     */
    public void setIsTop(Byte isTop) {
        this.isTop = isTop;
    }

    /**
     * 获取有效状态 // 1：有效， 0：无效
     */
    public Byte getIsActive() {
        return isActive;
    }

    /**
     * 设置有效状态 // 1：有效， 0：无效
     */
    public void setIsActive(Byte isActive) {
        this.isActive = isActive;
    }

    /**
     * 获取删除状态 // 1：已删除， 0：未删除
     */
    public Byte getIsDeleted() {
        return isDeleted;
    }

    /**
     * 设置删除状态 // 1：已删除， 0：未删除
     */
    public void setIsDeleted(Byte isDeleted) {
        this.isDeleted = isDeleted;
    }

    /**
     * 获取创建人id
     */
    public Long getCreateBy() {
        return createBy;
    }

    /**
     * 设置创建人id
     */
    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }

    /**
     * 获取创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 设置创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取更新人id
     */
    public Long getUpdateBy() {
        return updateBy;
    }

    /**
     * 设置更新人id
     */
    public void setUpdateBy(Long updateBy) {
        this.updateBy = updateBy;
    }

    /**
     * 获取更新时间
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * 设置更新时间
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}