package com.vipshop.adp.common.entity;

import java.io.Serializable;
import java.util.Date;

public class AdpStoreInfo implements Serializable {
    private static final long serialVersionUID = 1L;

    /** 主键
     */
    private Long id;

    /** 用户ID
     */
    private Long userId;

    /** 店铺头像链接
     */
    private String portraitUrl;

    /** 店铺名称
     */
    private String storeName;

    /** 店铺简介
     */
    private String storeBrief;

    /** 店铺背景图链接
     */
    private String bgImgUrl;

    /** 有效状态 // 1：有效， 0：无效
     */
    private Byte isActive;

    /** 删除状态 // 1：已删除， 0：未删除
     */
    private Byte isDeleted;

    /** 创建人id
     */
    private Long createBy;

    /** 创建时间
     */
    private Date createTime;

    /** 更新人id
     */
    private Long updateBy;

    /** 更新时间
     */
    private Date updateTime;

    /**
     * 获取主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取用户ID
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * 设置用户ID
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * 获取店铺头像链接
     */
    public String getPortraitUrl() {
        return portraitUrl;
    }

    /**
     * 设置店铺头像链接
     */
    public void setPortraitUrl(String portraitUrl) {
        this.portraitUrl = portraitUrl == null ? null : portraitUrl.trim();
    }

    /**
     * 获取店铺名称
     */
    public String getStoreName() {
        return storeName;
    }

    /**
     * 设置店铺名称
     */
    public void setStoreName(String storeName) {
        this.storeName = storeName == null ? null : storeName.trim();
    }

    /**
     * 获取店铺简介
     */
    public String getStoreBrief() {
        return storeBrief;
    }

    /**
     * 设置店铺简介
     */
    public void setStoreBrief(String storeBrief) {
        this.storeBrief = storeBrief == null ? null : storeBrief.trim();
    }

    /**
     * 获取店铺背景图链接
     */
    public String getBgImgUrl() {
        return bgImgUrl;
    }

    /**
     * 设置店铺背景图链接
     */
    public void setBgImgUrl(String bgImgUrl) {
        this.bgImgUrl = bgImgUrl == null ? null : bgImgUrl.trim();
    }

    /**
     * 获取有效状态 // 1：有效， 0：无效
     */
    public Byte getIsActive() {
        return isActive;
    }

    /**
     * 设置有效状态 // 1：有效， 0：无效
     */
    public void setIsActive(Byte isActive) {
        this.isActive = isActive;
    }

    /**
     * 获取删除状态 // 1：已删除， 0：未删除
     */
    public Byte getIsDeleted() {
        return isDeleted;
    }

    /**
     * 设置删除状态 // 1：已删除， 0：未删除
     */
    public void setIsDeleted(Byte isDeleted) {
        this.isDeleted = isDeleted;
    }

    /**
     * 获取创建人id
     */
    public Long getCreateBy() {
        return createBy;
    }

    /**
     * 设置创建人id
     */
    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }

    /**
     * 获取创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 设置创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取更新人id
     */
    public Long getUpdateBy() {
        return updateBy;
    }

    /**
     * 设置更新人id
     */
    public void setUpdateBy(Long updateBy) {
        this.updateBy = updateBy;
    }

    /**
     * 获取更新时间
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * 设置更新时间
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}