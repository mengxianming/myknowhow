package com.vipshop.adp.common.dao;

import com.vipshop.adp.common.entity.AdpStoreGoods;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AdpStoreGoodsMapper {
    int deleteById(Long id);

    int insert(AdpStoreGoods record);

    int insertSelective(AdpStoreGoods record);

    AdpStoreGoods selectById(Long id);

    int updateSelective(AdpStoreGoods record);

    int update(AdpStoreGoods record);

    List<AdpStoreGoods> selectByFeature(AdpStoreGoods feature);

    List<AdpStoreGoods> selectByFieldList(@Param("field") String field, @Param("values") List<?> values);

    int deleteByFeature(AdpStoreGoods feature);

    List<AdpStoreGoods> selectByCriteria(QCriteria criteria);

    List<Map<String, Object>> selectRawByCriteria(SelectableCriteria criteria);
}